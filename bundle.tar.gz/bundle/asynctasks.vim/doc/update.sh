#! /bin/sh
~/github/vim-tools/html2vimdoc/bin/python ~/github/vim-tools/html2vimdoc.py -f asynctasks asynctasks.md > asynctasks.txt
